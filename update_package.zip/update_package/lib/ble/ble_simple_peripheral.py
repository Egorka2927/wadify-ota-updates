# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()

# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time
from lib.ble.ble_advertising import advertising_payload
from lib.ble.ble_advertising import decode_name, decode_services

from micropython import const

_IRQ_CENTRAL_CONNECT = const(1)
_IRQ_CENTRAL_DISCONNECT = const(2)
_IRQ_GATTS_WRITE = const(3)

_FLAG_READ = const(0x0002)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)
_FLAG_WRITE = const(0x0008)
_FLAG_NOTIFY = const(0x0010)

_UART_UUID = bluetooth.UUID("6689d69d-e57a-47ab-b634-7fc8ca7df32e")
_UART_TX = (
    bluetooth.UUID("84ceae82-ac69-4783-85b4-a90716985c6f"),
    _FLAG_READ | _FLAG_NOTIFY,
)
_UART_RX = (
    bluetooth.UUID("b0bb3730-1828-44c3-8992-52afc81444d8"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)
_UART_SERVICE = (
    _UART_UUID,
    (_UART_TX, _UART_RX),
)


class BLESimplePeripheral:
    def __init__(self, ble, name="WMC"):
        self._ble = ble
        self._ble.active(True)
        self._ble.irq(self._irq)
        self._write_callback = None
        self._payload = advertising_payload(name=name, services=[_UART_UUID])
        self.secured = False
        self.connected = False
        self.connectedALO = False
        self._ble.active(False)
        
    def restart(self):
        self._ble.active(True)
        self.secured = False
        self.connected = False
        self.connectedALO = False
        ((self._handle_tx, self._handle_rx),) = self._ble.gatts_register_services((_UART_SERVICE,))
        self._ble.gatts_set_buffer(self._handle_rx, 512)
        self._connections = set()
        self._advertise()

    def _irq(self, event, data):
        # Track connections so we can send notifications.
        if event == _IRQ_CENTRAL_CONNECT:
            self.connected = True
            self.connectedALO = True
            conn_handle, _, _ = data
            print("New connection", conn_handle)
            self._connections.add(conn_handle)
        elif event == _IRQ_CENTRAL_DISCONNECT:
            self.connected = False
            conn_handle, _, _ = data
            print("Disconnected", conn_handle)
            self._connections.remove(conn_handle)
            self.secured = False
            # Start advertising again to allow a new connection. Alsways connects when there is an available node.
            self._advertise()
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            value = self._ble.gatts_read(value_handle)
            value = value.decode('UTF-8')
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)

    def send(self, data):
        self._ble.gatts_write(self._handle_tx, data)
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)

    def is_connected(self):
        return len(self._connections) > 0

    def _advertise(self, interval_us=50000):
        print("Starting advertising with name " + decode_name(self._payload) + " and services ")
        print(decode_services(self._payload))
        self._ble.gap_advertise(interval_us, adv_data=self._payload)

    def stop_advertise(self):
        print("Stopped advertising")
        self.connected = False
        self.secured = False
        self.connectedALO = False
        self._ble.gap_advertise(0, adv_data=self._payload)
    
    def on_write(self, callback):
        self._write_callback = callback


def demo():
    ble = bluetooth.BLE()
    p = BLESimplePeripheral(ble)

    def on_rx(v):
        print("RX", v)

    p.on_write(on_rx)

    i = 0
    while True:
        if p.is_connected():
            # Short burst of queued notifications.
            for _ in range(3):
                data = str(i) + "_"
                print("TX", data)
                p.send(data)
                i += 1
        time.sleep_ms(100)


if __name__ == "__main__":
    demo()


