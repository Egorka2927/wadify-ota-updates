from machine import Pin
from ds18x20 import DS18X20
from onewire import OneWire

from components.sensors.sensor import Sensor


class TemperatureSensor(Sensor):
    def __init__(self, pin: int, rounding: int = 1) -> None:
        self.sensors = DS18X20(OneWire(Pin(pin)))
        self.rounding = rounding

        # Throw away garbage from first reading
        self.get_reading()

    def get_reading(self):
        """
        Returns a list of values (in celsius) for each temperature sensor connected to the OneWire bus.
        """
        self.sensors.convert_temp()
        data = [self.sensors.read_temp(sensor) for sensor in self.sensors.scan()]
        return [round(entry, self.rounding) for entry in data]
