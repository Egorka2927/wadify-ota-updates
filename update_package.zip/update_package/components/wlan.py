import network
import time


class WLAN:
    def __init__(self, ssid, password, max_attempts=5) -> None:
        self.wlan = network.WLAN(network.STA_IF)
        self.wlan.active(True)
        self.ssid = ssid
        self.password = password
        self.max_attempts = max_attempts
        self.connect()

    def connect(self) -> None:
        """Connects to Wi-Fi, if it is not already connected."""
        if self.wlan.isconnected():
            return

        print(f"Connecting to Wi-Fi '{self.ssid}'", end="")
        attempt = 0
        while not self.wlan.isconnected() and attempt < self.max_attempts:
            self.wlan.scan()
            self.wlan.connect(self.ssid, self.password)
            time_now = time.ticks_ms()
            attempt_timeout = time_now + 1000
            while not self.wlan.isconnected() and time_now < attempt_timeout:
                time_now = time.ticks_ms()
            attempt += 1
            print(".", end="")

        print("")
        if attempt == self.max_attempts:
            print("Failed to connect")
        else:
            print("Connection established")

    def is_connected(self):
        return self.wlan.isconnected()
