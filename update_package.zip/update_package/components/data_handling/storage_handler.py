from os import mkdir, rmdir, listdir, remove
from uuid import uuid4
import json

from components.data_handling.queue import Queue
import components.data_handling.mongodb as mongodb


def safe_mkdir(directory: str):
    """
    os.path() doesn't exist in MicroPython,
    so instead of checking if the dir already exists,
    we try to make the directory,
    and then catch the FileExistsError instead.

    FileExistsError doesn't exist in MicroPython either,
    so we just have to catch all exceptions.
    """
    try:
        mkdir(directory)
    except Exception:
        pass


class StorageHandler:
    def __init__(self, device_name, save_dir) -> None:
        self.save_dir = save_dir
        self.errors_dir = "/errors"
        self.session_remaining_files = []

        safe_mkdir(self.save_dir)
        safe_mkdir(self.errors_dir)

        self.init_device_id(device_name)
        self.get_next_session_id()

    def init_device_id(self, device_name):
        path = "/.id"
        identifier = ""
        try:
            f = open(path, "r")
        except OSError:
            f = open(path, "x")
            identifier = str(uuid4())
            f.write(identifier)
        else:
            identifier = f.read()

        f.close()
        self.device_id = f"{device_name}-{identifier}"

    def get_device_id(self):
        return self.device_id

    def save_error(self, error_data: dict):
        files = listdir(self.errors_dir)
        error_id = len([True for f in files if self.session_id == int(f.split("_")[1])])
        error_file_path = f"{self.errors_dir}/{self.session_id}_{error_id}.json"
        print(f"Saving error to {error_file_path}...")
        with open(error_file_path, "w", encoding="utf-8") as file:
            json.dump(error_data, file)
        print("Error saved successfully.")

    def save_data(self, data: dict):
        if str(self.session_id) not in listdir(self.save_dir):
            safe_mkdir(self.session_dir)
        save_id = len(listdir(self.session_dir))

        new_data = data.copy()
        for value in new_data.values():
            if isinstance(value, Queue):
                value = value.toList()

        new_data["Device ID"] = self.device_id
        new_data["Session ID"] = self.session_id

        save_file_path = f"{self.session_dir}/{save_id}.json"
        print(f"Saving to {save_file_path}...")
        with open(save_file_path, "w", encoding="utf-8") as file:
            json.dump(new_data, file)

        print("Data saved successfully.")

    def upload_and_delete_data(self):
        """Uploads session and error data and then deletes uploaded files."""
        # Upload and (if successful) remove each existing error file.
        try:
            for error_file in listdir(self.errors_dir):
                error_file_path = self.errors_dir + "/" + error_file
                with open(error_file_path, "r", encoding="utf-8") as file:
                    error_data = json.load(file)

                print(f"Uploading '{error_file_path}'...")
                if mongodb.add_error(error_data, "WadifyDebug"):
                    print("file uploaded successfully.")
                    remove(error_file_path)

        except OSError:  # folder is empty. do nothing.
            pass

        # Upload and (if successful) remove all session data.
        try:
            sessions = [int(session) for session in listdir(self.save_dir)]
            sessions.sort()
            for session in sessions:
                session_path = f"{self.save_dir}/{session}"

                saves = [int(save[:-5]) for save in listdir(session_path)]
                saves.sort()
                for save in saves:
                    save_path = f"{session_path}/{save}.json"
                    with open(save_path, "r", encoding="utf-8") as file:
                        data = json.load(file)

                    print(f"Uploading '{save_path}'...")
                    if mongodb.add_session_data(data, "Wadify"):
                        print("file uploaded successfully.")
                        remove(save_path)
                    else:
                        print("Upload failed.")
                        return

                if 0 == len(listdir(session_path)):
                    rmdir(session_path)
        except OSError:  # folder is empty. do nothing.
            pass

    def get_next_session_id(self):
        path = "/.session_id"
        identifier = ""
        try:
            f = open(path, "r")
        except OSError:
            f = open(path, "x")
            identifier = str(0)
            f.write(identifier)
        else:
            identifier = f.read()

        f.close()
        identifier = int(identifier)
        self.session_id = identifier
        with open(path, "w") as f:
            f.write(str(identifier + 1))

        self.session_dir = f"{self.save_dir}/{self.session_id}"
