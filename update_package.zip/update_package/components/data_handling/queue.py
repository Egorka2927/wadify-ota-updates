class Queue:
    """
    A simple queue implemenation using a list.
    Has an option to set max_size.
    When the max size is reached, on push, the queue will pop and discard an element.
    This enables the queue to only store the max_size newest elements that are added.
    """

    def __init__(self, max_size: int | None = None) -> None:
        self.list = []
        self.max_size = max_size

    def __str__(self) -> str:
        return str(self.list)

    def __repr__(self) -> str:
        return repr(self.list)

    def __eq__(self, __o: object) -> bool:
        if isinstance(__o, Queue):
            return self.list == __o.list
        return False

    def dequeue(self) -> any:
        return self.list.pop(0)

    def enqueue(self, item: any) -> None:
        if self.max_size is not None and len(self.list) == self.max_size:
            self.dequeue()

        self.list.append(item)

    def clear(self):
        self.list = []

    def toList(self) -> list:
        return self.list.copy()
