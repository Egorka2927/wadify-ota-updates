from components.sensors.tds_sensor import TDSSensor
from components.sensors.echo_sensor import EchoSensor


class UndefinedValidatorException(Exception):
    def __init__(self, validator):
        message = (
            f"{validator} attempted to use for validation, when none were detected"
        )
        super().__init__(message)


class SessionValidator:
    def __init__(self, sensors: list[EchoSensor] | list[TDSSensor], parameters) -> None:
        self.sensors = sensors
        self.is_session = False
        self.validation_counter = 0
        self.max_validations = parameters["Readings"]

        if parameters["Method"] == "Echo":
            if parameters["Echo Distance"]["_unit"] == "mm":
                factor = 1000
            elif parameters["Echo Distance"]["_unit"] == "cm":
                factor = 1
            else:
                raise ValueError(
                    'Unit type for echo distance not configured properly. Valid values are ["mm", "cm"]'
                )
            self.min = int(parameters["Echo Distance"]["Min"] * factor)
            self.max = int(parameters["Echo Distance"]["Max"] * factor)
        elif parameters["Method"] == "TDS":
            self.min = parameters["TDS Threshold"]
            self.max = 100000
        else:
            raise Exception("Invalid sensor used for validation")

    def person_detected(self):
        return any(
            (self.min < sensor.get_reading() < self.max) for sensor in self.sensors
        )

    def has_session(self):
        # Person detection unchanged
        if self.is_session == self.person_detected():
            self.validation_counter = 0
            return self.is_session

        # Person detection changed
        self.validation_counter += 1

        # Change validated. Flip the 'has session' switch
        if self.validation_counter >= self.max_validations:
            self.is_session = not self.is_session
            self.validation_counter = 0

        return self.is_session
