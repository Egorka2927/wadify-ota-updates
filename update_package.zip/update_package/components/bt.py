import bluetooth
import hashlib
import binascii
import uos
import cryptolib
import json
from lib.ble.ble_simple_peripheral import BLESimplePeripheral
from components.message_handler import MessageHandler
from sys import print_exception


# Bluetooth Main class
class BT:
    def __init__(self, name=None) -> None:
        self.mh = MessageHandler()
        self.ble = bluetooth.BLE()
        if name is None:
            self.sp = BLESimplePeripheral(self.ble)
        else:
            self.sp = BLESimplePeripheral(self.ble, name)
        self.running = False

        # Defining on receive behaviour
        def on_rx(v):
            print("RX_: ", v)
            self.handle_message(v)

        self.sp.on_write(on_rx)

    def start_bt(self) -> None:
        if not self.running:
            self.sp.restart()
            self.running = True
            print("Successfully started bluetooth")
        else:
            print("Bluetooth is already turned on")

    def stop_bt(self) -> None:
        if self.running:
            self.sp.stop_advertise()
            self.ble.active(False)
            self.running = False
            print("Successfully stopped bluetooth")
        else:
            print("Bluetooth is already turned off")

    def is_connected(self) -> bool:
        return self.sp.connected

    def is_connectedALO(self) -> bool:
        return self.sp.connectedALO

    # Sending of unencrypted message (USAGE ONLY FOR CONFIRMING/DENYING PASSWORD MATCH)
    def send_message(self, message) -> None:
        if self.sp.is_connected():
            self.sp.send(str(message).encode())

    # Send of encrypted message (USAGE ONLY AFTER PASSWORD CONFIRMATION AND WHEN SECURED)
    def send_message_encrypted(self, message) -> None:
        if self.sp.is_connected():
            encrypted = self.encrypt(message)
            self.sp.send(str(encrypted).encode())

    def handle_message(self, v) -> None:
        # Sending of messages when there is a secured connection
        if self.sp.secured:
            decrypted = self.decrypt(v)
            reply = self.mh.handle_message(decrypted)
            self.send_message_encrypted(reply)
        # Checking of password matching
        else:
            if self.password_checker(v):
                self.send_message("1")
            else:
                self.send_message("0")

    # Checking if the incoming password hash is a match
    def password_checker(self, v) -> bool:
        hasher = hashlib.sha256(self.load_device_pass())
        hashedPassword = binascii.hexlify(hasher.digest())
        if hashedPassword.decode("utf-8") == v:
            self.sp.secured = True
            return True
        else:
            return False

    # Encryption using AES-CBC with PKCS7 padding
    def encrypt(self, message):
        iv = uos.urandom(16)
        hasher = hashlib.sha256(self.load_device_pass())
        hashedKey = binascii.hexlify(hasher.digest())

        chiper = cryptolib.aes(hashedKey[0:32], 2, iv)

        message_bytes = message.encode()
        padding_length = 16 - len(message_bytes) % 16
        padded_message = message_bytes + bytes([padding_length] * padding_length)

        encrypted = chiper.encrypt(padded_message)
        formated_message = self.EncryptedMessage(
            binascii.b2a_base64(iv)[:-1], binascii.b2a_base64(encrypted)[:-1]
        )

        return json.dumps(formated_message.__dict__)

    # Same as encryption
    def decrypt(self, encrypted):
        try:
            decoded_message = json.loads(encrypted)
        except ValueError as exc:
            print("Error in parsing JSON from : " + str(encrypted))
            print_exception(exc)
            return self.redirect_error(5, "Bad decryption")

        try:
            iv = decoded_message["iv"]
        except KeyError as exc:
            print("There was no iv available in JSON object : " + str(decoded_message))
            print_exception(exc)
            return self.redirect_error(5, "Bad decryption")

        try:
            chiper = decoded_message["chiper"]
        except KeyError as exc:
            print(
                "There was no chiper available in JSON object : " + str(decoded_message)
            )
            print_exception(exc)
            return self.redirect_error(5, "Bad decryption")

        try:
            hasher = hashlib.sha256(self.load_device_pass())
            hashedKey = binascii.hexlify(hasher.digest())

            dechiper = cryptolib.aes(hashedKey[0:32], 2, (binascii.a2b_base64(iv)))
            decrypted = dechiper.decrypt(binascii.a2b_base64(chiper))

            decoded = decrypted.decode("UTF-8")

            chars_to_remove = [chr(i) for i in range(1, 17)]

            for char in chars_to_remove:
                decoded = decoded.rstrip(char)

            return str(decoded)
        except Exception as exc:
            print("Something went wront with decryption")
            print_exception(exc)
            return self.redirect_error(5, "Bad decryption")

    def redirect_error(self, code, description):
        return json.dumps(
            self.RedirectedError(-1, self.mh.send_response(code, description))
        )

    # Default format for an encrypted message
    class EncryptedMessage:
        def __init__(self, input_iv, input_chiper) -> None:
            self.iv = input_iv
            self.chiper = input_chiper

    # Class used to redirect errors to messageHandler
    class RedirectedError:
        def __init__(self, redirect_ec, redirect_payload) -> None:
            self.execution_code = redirect_ec
            self.payload = redirect_payload

    def load_configs(self):
        with open("config/config.json", "r") as file:
            return json.load(file)

    def load_device_pass(self):
        data = self.load_configs()
        return data["Device"]["Password"]
