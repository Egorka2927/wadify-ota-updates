from machine import ADC

import components.sensors.sensor as sensor


class TDSSensor(sensor.Sensor):
    def __init__(self, pin: int, rounding: int = 1) -> None:
        self.sensor = ADC(pin)
        self.rounding = rounding

    def get_reading(self) -> float:
        """Gets Total Dissolved Solids values from the TDS sensor, measured in PPM."""
        while sensor.mutex:
            pass
        sensor.mutex = True
        reading = self.sensor.read_u16()
        voltage = (reading * 3.3) / 65536
        ppm = ((133.42 * voltage**3) - (255.86 * voltage**2) + (857.39 * voltage)) * 0.5
        sensor.mutex = False
        return round(ppm, self.rounding)
