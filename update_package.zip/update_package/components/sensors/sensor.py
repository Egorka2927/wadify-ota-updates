mutex = False


class Sensor:
    def __init__(self) -> None:
        pass

    def get_reading(self):
        pass
