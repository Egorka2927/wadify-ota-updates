from sys import print_exception
import requests_custom as requests
import gc


def transpose_list(data: list[list]):
    """
    Transpose 2D lists such that data of the form:
    [[sensor1, sensor2], [sensor1, sensor2], ...]
    becomes:
    [[sensor1, sensor1 ...], [sensor2, sensor2 ...]]
    """
    return list(map(list, zip(*data)))


def each(array):
    """
    Make mongodb insert an array by element,
    instead of inserting as one object.
    """
    return {"$each": array}


def add_error(error_data, database):
    return insert_one(error_data, error_data["Device ID"], database)


def add_session_data(data: dict, database):
    temp_data = transpose_list(data.pop("Temperature"))
    append_data = {
        f"Temperature.{i}": each(sensor) for i, sensor in enumerate(temp_data)
    }
    if "Distance" in data.keys():
        echo_data = transpose_list(data.pop("Distance"))
        append_data |= {
            f"Distance.{i}": each(sensor) for i, sensor in enumerate(echo_data)
        }
    append_data["TDS"] = each(data.pop("TDS"))

    update_query = {"$push": append_data, "$set": data}
    if "Feedback" in data.keys():
        update_query["$addToSet"] = {"Feedback": each(data.pop("Feedback"))}

    return update_one(
        update_query, {"Session ID": data["Session ID"]}, data["Device ID"], database
    )


def update_one(data, search_filter, collection, database):
    request_data = {"filter": search_filter, "update": data}
    return send_request("updateOne", request_data, collection, database)


def insert_one(data, collection, database):
    return send_request("insertOne", data, collection, database)


def find_one(search_filter, collection, database):
    return send_request("findOne", search_filter, collection, database)


def send_request(action, data, collection, database):
    url = "https://eu-central-1.aws.data.mongodb-api.com/app/data-asxfc/endpoint/data/v1/action/"
    headers = {
        "api-key": "nqHUGUB0RnZPHQ5iaTfxuUnzHSPlUE2HVtgIU3P6F1J7OrNcCesopVRpTf0IFfqv",
    }

    payload = {
        "dataSource": "Cluster0",
        "database": database,
        "collection": collection,
    }
    if action == "insertOne":
        payload["document"] = data

    elif action == "findOne":
        payload["filter"] = data

    elif action == "updateOne":
        payload["filter"] = data["filter"]
        payload["update"] = data["update"]
        payload["upsert"] = True

    gc.collect()
    try:
        response = requests.post(url + action, headers=headers, json=payload)
    except Exception as exc:
        print_exception(exc)
        return False

    result = 199 < response.status_code < 203
    if not result:
        print("Request failed.")
        print(f"Code {response.status_code}: {response.text}")
    response.close()
    return result
