from machine import Pin


class Button:
    def __init__(self, pin, label=None) -> None:
        self.pin = Pin(pin, Pin.IN, Pin.PULL_UP)
        self.label = label
        
    def is_pressed(self):
        return not self.pin.value()