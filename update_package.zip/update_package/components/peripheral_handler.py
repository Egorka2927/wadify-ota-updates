from components.sensors.temperature_sensor import TemperatureSensor
from components.sensors.tds_sensor import TDSSensor
from components.button import Button


class PeripheralHandler:
    def __init__(self, peripherals: dict, undoable_feedback):
        peripheral_keys = peripherals.keys()

        if "Temperature" not in peripheral_keys:
            raise ValueError("Temperature sensor not configured properly.")
        if "TDS" not in peripheral_keys:
            raise ValueError("TDS sensor not configured properly.")

        self.temp_sensors = TemperatureSensor(peripherals["Temperature"])
        self.tds_sensor = TDSSensor(peripherals["TDS"])

        self.echos_enabled = peripherals["Echos"]["Enabled"]
        if self.echos_enabled:
            from components.sensors.echo_sensor import EchoSensor

            self.echo_sensors = [
                EchoSensor(*echo.values()) for echo in peripherals["Echos"]["Devices"]
            ]

        self.flusher_enabled = peripherals["Servo"]["Enabled"]
        if self.flusher_enabled:
            from components.flusher import Flusher

            self.flusher = Flusher(peripherals["Servo"]["Pin"])

        self.feedback_enabled = peripherals["Feedback Buttons"]["Enabled"]
        if self.feedback_enabled:
            from components.feedback_handler import FeedbackHandler

            button_kv = peripherals["Feedback Buttons"]["Devices"].items()
            buttons = [Button(pin, label) for label, pin in button_kv]
            self.feedback_handler = FeedbackHandler(buttons, undoable_feedback)

    def handle_flush(self):
        if not self.flusher.has_flushed:
            self.flusher.flush()
            self.flusher.has_flushed = False
