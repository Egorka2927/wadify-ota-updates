from servo import Servo
import time


class Flusher:
    def __init__(self, servo_pin) -> None:
        self.servo = Servo(servo_pin)
        self.has_flushed = False

    def flush(self, flush_time=1.5):
        """Flushes the toilet for 'flush_time' seconds."""

        print(f"Flushing for {flush_time}s")
        self.servo.move(70)
        time.sleep(flush_time)
        self.servo.move(0)
        self.has_flushed = True
