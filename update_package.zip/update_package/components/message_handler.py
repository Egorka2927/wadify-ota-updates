import json
from sys import print_exception
from micropython import const

# Execution codes mapping + field names
ERROR_REDIRECT = const(-1)
REQUEST_ALL_CONFIGS = const(0)
MODIFY_WLAN_SSID = const(1)
TARGET_WLAN_SSID = const("SSID")
MODIFY_WLAN_PASSWORD = const(2)
TARGET_WLAN_PASSWORD = const("PASSWORD")
MODIFY_TDS_DETECTION_THRESHOLD = const(3)
TARGET_TDS_DETECTION_THRESHOLD = const("TDS_DETECTION_THRESHOLD")
MODIFY_OUT_OF_SESSION_DATA_SAVE_TIME_MS = const(4)
TARGET_OUT_OF_SESSION_DATA_SAVE_TIME_MS = const("OUT_OF_SESSION_DATA_SAVE_TIME_MS")
MODIFY_DEVICE_PASSWORD = const(5)
TARGET_DEVICE_PASSWORD = const("DEVICE_PASSWORD")
MODIFY_TOILET_VOLUME = const(6)
CONFIG_TOILET_VOLUME = const(7)
TARGET_TOILET_VOLUME = const("TOILET_VOLUME")

# Return status codes
OK = const(0)
JSON_PARSE_ERROR = const(1)
JSON_MISSING_FIELD = const(2)
INCORRECT_DATA_TYPE = const(3)
INCORRECT_EXECUTION_CODE = const(4)


class MessageHandler:
    def __init__(self) -> None:
        pass

    def handle_message(self, message):
        # Checking for any json errors
        try:
            decoded_message = json.loads(message)
        except ValueError as exc:
            print("Error in parsing JSON from : " + str(message))
            print_exception(exc)
            return self.send_response(
                JSON_PARSE_ERROR, "There was a problem in parsing JSON"
            )
        try:
            execution_code = decoded_message["execution_code"]
        except KeyError as exc:
            print(
                "There was no execution_code available in JSON object : "
                + str(decoded_message)
            )
            print_exception(exc)
            return self.send_response(
                JSON_MISSING_FIELD, "The field 'execution_code' is missing"
            )

        if execution_code == -1:
            return self.send_response(5, payload)
        try:
            payload = decoded_message["payload"]
        except KeyError as exc:
            print(
                "There was no payload available in JSON object : "
                + str(decoded_message)
            )
            print_exception(exc)
            return self.send_response(
                JSON_MISSING_FIELD, "The field 'payload' is missing"
            )
        print("Running execution code " + str(execution_code))

        configs = self.load_configs()

        # Checking all the execution codes
        if execution_code == ERROR_REDIRECT:
            return payload
        if execution_code == REQUEST_ALL_CONFIGS:
            return self.send_configs(message, configs)

        elif execution_code == MODIFY_WLAN_SSID:
            configs["Wi-Fi"]["SSID"] = payload
            return self.modify_config(TARGET_WLAN_SSID, payload, configs)

        elif execution_code == MODIFY_WLAN_PASSWORD:
            configs["Wi-Fi"]["PASSWORD"] = payload
            return self.modify_config(TARGET_WLAN_PASSWORD, payload, configs)

        elif execution_code == MODIFY_TDS_DETECTION_THRESHOLD:
            try:
                payload = float(payload)
            except ValueError as exp:
                return self.send_response(INCORRECT_DATA_TYPE, "Expected float")
            
            configs["Presence Detection"]["TDS Threshold"] = payload
            return self.modify_config(
                TARGET_TDS_DETECTION_THRESHOLD,
                payload,
                configs,
            )

        elif execution_code == MODIFY_OUT_OF_SESSION_DATA_SAVE_TIME_MS:
            try:
                payload = float(payload)
            except ValueError as exp:
                return self.send_response(INCORRECT_DATA_TYPE, "Expected float")
            
            configs["Timers"]["Out Of Session Data Save"] = payload
            return self.modify_config(
                TARGET_OUT_OF_SESSION_DATA_SAVE_TIME_MS,
                payload,
                configs,
            )

        elif execution_code == MODIFY_DEVICE_PASSWORD:
            configs["Device"]["Password"] = payload
            return self.modify_config(TARGET_DEVICE_PASSWORD, payload, configs)
        
        elif execution_code == MODIFY_TOILET_VOLUME:
            try:
                payload = float(payload)
            except ValueError as exp:
                return self.send_response(INCORRECT_DATA_TYPE, "Expected float")
            
            configs["Toilet"]["Volume"] = payload
            return self.modify_config(
                TARGET_TOILET_VOLUME,
                payload,
                configs,
            )
        
        elif execution_code == CONFIG_TOILET_VOLUME:
            try:
                payload = float(payload)
            except ValueError as exp:
                return self.send_response(INCORRECT_DATA_TYPE, "Expected float")
            result = 200 * (85 / ((0.0812 * (payload/3.65) + 0/0929)))
            payload["Toilet"]["Volume"] = result
            return self.modify_config(
                TARGET_TOILET_VOLUME,
                result,
                configs,
            )
        
        else:
            print("Execution code " + str(execution_code) + " could not be found")
            return self.send_response(
                INCORRECT_EXECUTION_CODE, "The provided execution code is not mapped"
            )

    def modify_config(self, target_name, target_value, configs):
        self.save_config(configs)
        print("Successfully changed " + target_name + " to " + str(target_value))
        return self.send_response(OK, "OK")

    # Send all the configuration values
    def send_configs(self, message, configs):
        config_values = self.ConfigValues(configs)
        return json.dumps(config_values.__dict__)

    # Send a generic response back
    def send_response(self, status_code, message):
        response = self.Response(status_code, message)
        return json.dumps(response.__dict__)

    def save_config(self, config):
        with open("config/config.json", "w") as file:
            json.dump(config, file, separators=(",", ":"))

    def load_configs(self):
        with open("config/config.json", "r") as file:
            return json.load(file)

    class ConfigValues:
        def __init__(self, configs) -> None:
            self.WIFI_SSID = configs["Wi-Fi"]["SSID"]
            self.WIFI_PASSWORD = configs["Wi-Fi"]["Password"]
            self.TDSDT = configs["Presence Detection"]["TDS Threshold"]
            self.OFS_SAVE_TIME = configs["Timers"]["Out Of Session Data Save"]
            self.DEVICE_PASS = configs["Device"]["Password"]
            self.TOILET_VOLUME = configs["Toilet"]["Volume"]

    class Response:
        def __init__(self, status_code, message) -> None:
            self.status_code = status_code
            self.message = message
