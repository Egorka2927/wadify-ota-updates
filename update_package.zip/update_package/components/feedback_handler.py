from components.button import Button


class FeedbackHandler:
    def __init__(self, buttons: list[Button], undoable_feedback) -> None:
        self.undoable_feedback = undoable_feedback
        self.buttons = buttons
        self.was_pressed = [False for _ in self.buttons]

    def check_feedback(self):
        for i, pressed in enumerate(self.was_pressed):
            if pressed and not self.undoable_feedback:
                continue

            if self.buttons[i].is_pressed():
                self.was_pressed[i] = not pressed

    def get_and_reset_feedback(self):
        feedback = [
            self.buttons[i].label
            for i, pressed in enumerate(self.was_pressed)
            if pressed
        ]
        self.was_pressed = [False for _ in self.was_pressed]
        return feedback
