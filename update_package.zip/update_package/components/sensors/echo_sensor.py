from time import sleep_us, ticks_us
from machine import Pin

import components.sensors.sensor as sensor


class EchoSensor(sensor.Sensor):
    def __init__(self, read_pin: int, trigger_pin: int, rounding: int = 1) -> None:
        self.read = Pin(read_pin, Pin.IN)
        self.trig = Pin(trigger_pin, Pin.OUT)
        self.rounding = rounding

    def get_reading(self) -> float:
        """
        Gets a list of distances (in cm).
        Each index corresponds to the distance measured by one echo sensor.
        """
        while sensor.mutex:
            pass
        sensor.mutex = True
        signal_off = 0
        signal_on = 0

        self.trig.low()
        sleep_us(2)
        self.trig.high()
        sleep_us(5)
        self.trig.low()

        while self.read.value() == 0:
            signal_off = ticks_us()

        while self.read.value() == 1:
            signal_on = ticks_us()

        time_passed = signal_on - signal_off
        distance = (time_passed * 0.0343) / 2

        sensor.mutex = False
        return round(distance, self.rounding)
