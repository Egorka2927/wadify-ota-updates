from machine import RTC
import time
import ntptime

# Make naming more convenient
tm_year = 0
tm_mon = 1  # range [1, 12]
tm_mday = 2  # range [1, 31]
tm_hour = 3  # range [0, 23]
tm_min = 4  # range [0, 59]
tm_sec = 5  # range [0, 61]
tm_wday = 6  # range [0, 6] Monday = 0
tm_yday = 7  # range [0, 366]
tm_isdst = 8  # 0, 1 or -1


def zfill(s, width):
    # Pads the provided string with leading 0's to suit the specified 'chrs' length
    # Force # characters, fill with leading 0's
    return "{:0>{w}}".format(s, w=width)


def cet_time():
    """Convert the timezone from UTC to CET/CEST."""
    year = time.localtime()[0]  # get current year
    HHMarch = time.mktime(
        (year, 3, (31 - (int(5 * year / 4 + 4)) % 7), 1, 0, 0, 0, 0, 0)
    )  # Time of March change to CEST
    HHOctober = time.mktime(
        (year, 10, (31 - (int(5 * year / 4 + 1)) % 7), 1, 0, 0, 0, 0, 0)
    )  # Time of October change to CET
    now = time.time()
    if now < HHMarch:  # we are before last sunday of march
        cet = time.localtime(now + 3600)  # CET:  UTC+1H
    elif now < HHOctober:  # we are before last sunday of october
        cet = time.localtime(now + 7200)  # CEST: UTC+2H
        # print("we are before last sunday of october")
    else:  # we are after last sunday of october
        cet = time.localtime(now + 3600)  # CET:  UTC+1H
        # print("we are after last sunday of october")
    return cet


def set_time():
    # ntp_host = ["0.europe.pool.ntp.org", "1.europe.pool.ntp.org", "2.europe.pool.ntp.org", "3.europe.pool.ntp.org"] # Not used

    # print("UTC time before synchronization: %s" %str(time.localtime()))

    # if needed, we'll cycle over ntp-servers here using:
    # ntptime.host = "1.europe.pool.ntp.org"
    for _ in range(5):
        try:
            ntptime.settime()
        except OSError as exc:
            if exc.args[0] == 110:  # ETIMEDOUT
                continue
        break

    # print("UTC time after synchronization: %s" %str(time.localtime()))
    t = cet_time()
    # print("CET time after synchronization : %s" %str(t))

    # Set local clock to adjusted time
    RTC().datetime(
        (
            t[tm_year],
            t[tm_mon],
            t[tm_mday],
            t[tm_wday] + 1,
            t[tm_hour],
            t[tm_min],
            t[tm_sec],
            0,
        )
    )
    print("Local time is:", get_datetime())


def get_date():
    t = [zfill(str(i), 2) for i in time.localtime()]
    return "-".join(t[tm_year : tm_mday + 1])


def get_time():
    t = [zfill(str(i), 2) for i in time.localtime()]
    return ":".join(t[tm_hour : tm_sec + 1])


def get_datetime():
    return get_date() + " " + get_time()


def time_diff(a, b):
    a = [int(i) for i in a.split(":")]
    b = [int(i) for i in b.split(":")]
    diff = [(a[2 - i] - b[2 - i]) * (pow(60, i)) for i in range(3)]
    return abs(sum(diff))


def schedule():
    # Sync clock every day at 04:00:00
    t = time.localtime()
    if t[tm_hour] == 4 and t[tm_min] == 0 and t[tm_sec] == 0:
        print("Synchronizing time")
        set_time()
